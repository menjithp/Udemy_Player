import React ,{useState,useReducer} from "react";
const reducer=(state,action)=>{
  return {...state,value:action.data}
}

const initialstate={
  rule:"done",
  value:"valika"
}

export default function Index() {

  const [a,b]=useState({menjith:true,pratish:false})
  const [e,f]=useState({palani:"drone",chandra:"macha:",rushma:"drago"})

  const[c,d]=useReducer(reducer,initialstate)

  return (

    <div>
    <button onClick={()=>b({...a,menjith:false})}>olla</button>
    <button onClick={()=>f({...e,chandra:"good days on way"})}>oluila</button>
    <button onClick={()=>d({data:"billa voda treat"})}>yuolla</button>
    </div>
  )
}
